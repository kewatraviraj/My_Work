/**
 * 
 */
package edu.testDao;

/**
 * @author HP
 *
 */
public interface ExampleDao {

	//   public int insert(String testValue);
}
