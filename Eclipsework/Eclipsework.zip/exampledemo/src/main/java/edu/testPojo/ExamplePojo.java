/**
 * 
 */
package edu.testPojo;

/**
 * @author HP
 *
 */
public class ExamplePojo {
	
	private int num;
	private String testvalue;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getTestvalue() {
		return testvalue;
	}
	public void setTestvalue(String testvalue) {
		this.testvalue = testvalue;
	}
	
	
}
