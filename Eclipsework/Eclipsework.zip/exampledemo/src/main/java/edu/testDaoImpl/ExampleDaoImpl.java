/**
 * 
 */
package edu.testDaoImpl;

/**
 * @author HP
 *
 */
public class ExampleDaoImpl {

	

}
