/**
 * 
 */
package com.testDao;

/**
 * @author HP
 *
 */
public interface ExampleDao {

	   public int insert(String testValue);
}
