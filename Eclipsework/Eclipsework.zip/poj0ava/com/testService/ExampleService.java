/**
 * 
 */
package com.testService;

/**
 * @author HP
 *
 */
public class ExampleService {
	

}
