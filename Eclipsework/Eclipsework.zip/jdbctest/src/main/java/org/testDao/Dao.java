/**
 * 
 */
package org.testDao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.testPojo.Pojo;

/**
 * @author HP
 *
 */
public interface Dao {

	public int insert(Pojo Value) throws ClassNotFoundException, SQLException, IOException;
	public List<Pojo> getAllUser() throws ClassNotFoundException, SQLException, IOException;
	public boolean del(int i) throws ClassNotFoundException, SQLException, IOException;
}
