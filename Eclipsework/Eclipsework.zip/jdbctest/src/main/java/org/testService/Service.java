/**
 * 
 */
package org.testService;

/**
 * @author HP
 *
 */
public class Service {
	

}
